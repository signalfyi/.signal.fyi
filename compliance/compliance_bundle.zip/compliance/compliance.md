# Compliance Evidence Summary

This directory contains compliance evidence for daily vulnerability management tied to the parent Docker image `python:latest`.

## Mappings

| Framework  | Control                     | Evidence Provided |
|------------|-----------------------------|-------------------|
| SOC 2      | CC7.1 – Vulnerability Management     | [cc7.1.md](soc2/cc7.1.md) |
| ISO 27001  | A.12.6.1 – Technical Vulnerability Mgmt | [a.12.6.1.md](iso27001/a.12.6.1.md) |
| HIPAA      | 164.308(a)(8) – Security Mgmt Process | [164.308a8.md](hipaa/164.308a8.md) |

Machine-readable artifacts are stored in the [provenance](provenance/) directory.
