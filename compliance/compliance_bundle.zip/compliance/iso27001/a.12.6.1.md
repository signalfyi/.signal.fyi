## ISO 27001 - A.12.6.1 Evidence

- ✅ Technical vulnerability management
- ✅ Daily scan results tracked
- ✅ Backed by SBOM and CVE summary
