## SOC 2 - CC7.1 Evidence

- ✅ Daily vulnerability scanning via Trivy
- ✅ Timestamp and digest recorded
- ✅ Evidence committed to Git
