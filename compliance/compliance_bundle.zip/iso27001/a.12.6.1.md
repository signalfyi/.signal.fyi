# ISO 27001 A.12.6.1 Evidence
Linked to technical vulnerability management scans.