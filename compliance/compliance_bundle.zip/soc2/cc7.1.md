# SOC 2 CC7.1 Evidence
Linked to daily scan artifacts.